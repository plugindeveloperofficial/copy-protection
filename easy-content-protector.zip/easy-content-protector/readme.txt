=== Copy Protetion ===
Contributors: plugindeveloper	
Tags: content, content copy protection, content protection, copy protection, prevent copy, protect blog, image protect, image protection, no right click, plagiarism, secure content, content theft
Requires at least: 5.4
Requires PHP: 5.4
Tested up to: 5.9.2
Stable tag: 1.0.0
License: GPL V3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin prevent copy, cut, paste, inspect element and selection of the content. You can easily enable or disable it from dashboard. 

== Description ==
Simple plugin to prevent copy content.

== Installation ==
**Direct from Dashbaord:**
<ul>
<li>Please go to your website Dashboard</li>
<li>Plugins and Add new</li>
<li>Search for Copy Content</li>
<li>Install it and activate it.</li>
</ul>

**Manually Installation:**
<ul>
<li>Please go to https://wordpress.org/plugins/copy-content/</li>
<li>Download Zip file from there</li>
<li>Please go to your website Dashboard</li>
<li>Plugins and Add new</li>
<li>Uplaod zip file there</li>
<li>Install it and activate it.</li>
</ul>

== Changelog ==
= 1.0.0 =
<ul>
<li>Initialize Release</li>
</ul>
